package com.example.damn2.ui.ask;

import androidx.lifecycle.ViewModel;

public class AskViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}